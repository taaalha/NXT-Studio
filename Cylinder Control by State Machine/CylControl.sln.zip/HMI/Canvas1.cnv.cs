﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 5/26/2016
 * Time: 8:11 PM
 * 
 */

using System;
using System.Drawing;

using NxtControl.GuiFramework;


namespace HMI.Main.Canvases
{
	/// <summary>
	/// Description of Canvas1.
	/// </summary>
	public partial class Canvas1 : NxtControl.GuiFramework.HMICanvas
	{
		public Canvas1()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
	}
}
