﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 5/25/2016
 * Time: 9:41 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.Button
{
	/// <summary>
	/// Summary description for sDefault2.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new NxtControl.GuiFramework.DrawnButton();
			this.LABEL = new System.HMI.Symbols.Base.Execute<string>();
			// 
			// button1
			// 
			this.button1.Bounds = new NxtControl.Drawing.RectF(((float)(16)), ((float)(62)), ((float)(152)), ((float)(44)));
			this.button1.Brush = new NxtControl.Drawing.Brush("ButtonBrush");
			this.button1.Font = new NxtControl.Drawing.Font("ButtonFont");
			this.button1.InnerBorderColor = new NxtControl.Drawing.Color("ButtonInnerBorderColor");
			this.button1.Name = "button1";
			this.button1.Pen = new NxtControl.Drawing.Pen("ButtonPen");
			this.button1.Radius = 4;
			this.button1.Text = "Button";
			this.button1.TextColor = new NxtControl.Drawing.Color("ButtonTextColor");
			this.button1.TextColorMouseDown = new NxtControl.Drawing.Color("ButtonTextColorMouseDown");
			this.button1.Click += new System.EventHandler(this.DrawnButton1Click);
			// 
			// LABEL
			// 
			this.LABEL.BeginInit();
			this.LABEL.AngleIgnore = false;
			this.LABEL.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 45, 129);
			this.LABEL.IsOnlyInput = true;
			this.LABEL.Name = "LABEL";
			this.LABEL.TagName = "LABEL";
			this.LABEL.Value = null;
			this.LABEL.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.LABELValueChanged);
			this.LABEL.EndInit();
			// 
			// sDefault
			// 
			this.Name = "sDefault2";
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
									this.button1,
									this.LABEL});
			this.SymbolSize = new System.Drawing.Size(200, 200);
		}
		private System.HMI.Symbols.Base.Execute<string> LABEL;
		private NxtControl.GuiFramework.DrawnButton button1;
		#endregion
	}
}
