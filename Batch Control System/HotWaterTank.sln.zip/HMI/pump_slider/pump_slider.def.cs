using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region pump_slider_HMI;
#endregion pump_slider_HMI;

#endregion Definitions;

