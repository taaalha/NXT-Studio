﻿/*
 * Created by nxtSTUDIO.
 * User: valeriy
 * Date: 6/6/2017
 * Time: 10:09 AM
 * 
 */

using System;
using System.Drawing;

using NxtControl.GuiFramework;


namespace HMI.Main.Canvases
{
	/// <summary>
	/// Description of Canvas2.
	/// </summary>
	public partial class Canvas2 : NxtControl.GuiFramework.HMICanvas
	{
		public Canvas2()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
		
		void Trend1Load(object sender, EventArgs e)
		{
			
		}
	}
}
