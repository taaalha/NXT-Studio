using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region ThermometerS_HMI;
#endregion ThermometerS_HMI;

#endregion Definitions;

