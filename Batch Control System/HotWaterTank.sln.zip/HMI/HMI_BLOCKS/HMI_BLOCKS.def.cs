using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region HMI_BLOCKS_HMI;
#endregion HMI_BLOCKS_HMI;

#endregion Definitions;

