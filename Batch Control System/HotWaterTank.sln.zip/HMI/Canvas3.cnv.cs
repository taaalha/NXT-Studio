﻿/*
 * Created by nxtSTUDIO.
 * User: prana
 * Date: 4/6/2020
 * Time: 12:01 PM
 * 
 */

using System;
using System.Drawing;

using NxtControl.GuiFramework;


namespace HMI.Main.Canvases
{
	/// <summary>
	/// Description of Canvas3.
	/// </summary>
	public partial class Canvas3 : NxtControl.GuiFramework.HMICanvas
	{
		public Canvas3()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
	}
}
