﻿/*
 * Created by nxtSTUDIO.
 * User: prana
 * Date: 4/6/2020
 * Time: 12:02 PM
 * 
 */

using System;
using System.Drawing;

using NxtControl.GuiFramework;


namespace HMI.Main.Canvases
{
	/// <summary>
	/// Description of Canvas4.
	/// </summary>
	public partial class Canvas4 : NxtControl.GuiFramework.HMICanvas
	{
		public Canvas4()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
	}
}
