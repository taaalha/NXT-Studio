﻿/*
 * Created by nxtSTUDIO.
 * User: prana
 * Date: 4/6/2020
 * Time: 12:02 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;

using NxtControl.GuiFramework;

namespace HMI.Main.Canvases
{
	/// <summary>
	/// Summary description for Canvas4.
	/// </summary>
	partial class Canvas4
	{
		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      		this.Name = "Canvas4";
			this.Size = new System.Drawing.Size(1024,688);
			this.Brush = new NxtControl.Drawing.Brush("CanvasBrush");
            
            
		}
		#endregion
	}
}
