﻿/*
 * Created by nxtSTUDIO.
 * User: prana
 * Date: 3/26/2020
 * Time: 8:13 PM
 * 
 */

using System;
using System.Drawing;

using NxtControl.GuiFramework;


namespace HMI.Main.Canvases
{
	/// <summary>
	/// Description of Canvas4.
	/// </summary>
	public partial class Canvas : NxtControl.GuiFramework.HMICanvas
	{
		public Canvas()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
	}
}
