using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region Level_Control_Slider_HMI;
#endregion Level_Control_Slider_HMI;

#endregion Definitions;

